const btn=document.getElementById('generateBtn');
const theme=document.getElementById('themeToggle');

theme.onclick=()=>document.body.classList.toggle('dark');

let wavesurfer=WaveSurfer.create({
 container:'#waveform',
 waveColor:'gray',
 progressColor:'black'
});

btn.onclick=async()=>{
 alert('Connect your real TTS API here.');
};